# Install the INBRND flywheel section in Wix

Paste the complete `inbrnd-flywheel.js` into a Wix Velo custom-element file, or use its public Server URL. Set the tag to `inbrnd-flywheel`. The component contains only the diagram and, in teaching mode, its active-stage explanation and final payoff. Read without motion remains available. All page introductions, closing copy, headers, navigation, and footers belong to your Wix page.

Follow the matching runbook:

- [Teaching mode](runbooks/wix-teaching-copy-runbook.md)
- [Circle-only mode](runbooks/wix-diagram-only-runbook.md)

Use `asset-base="https://inbrnd.github.io/assets/"`, `content-mode="teaching"` (or `diagram`), `variant="wheel"`, and the measured `header-offset`. Existing attributes and the custom-element tag are preserved. `heading-level` controls the accessible framework heading. The legacy theme/emphasis attributes remain accepted without introducing additional effects.

The layout adapts to the actual element width, including narrow Wix columns. Allow full content height and normal page scrolling; do not constrain the entire experience to one fixed-height screen or a separately scrolling iframe. At short heights or with reduced motion it becomes an unpinned reading view.

Examples show only the component and include a no-JavaScript fallback. A Wix Editor custom element does not automatically receive that surrounding fallback HTML; validate the equivalent host-page content separately. The small page-code files configure the element; they do not replace the full component JavaScript.

Test a published Wix duplicate page before replacing the live section. GitHub Pages and local viewport checks do not certify Wix parent-container behavior or physical devices.

## Final UX polish

The five-stage narrative, scroll duration, ring progression, and approved sentence reveal are unchanged. The final pass keeps stage explanations readable at handoffs, avoids repeated font/diagram measurements during steady scrolling, and slightly increases diagram text in sections at 360px or narrower. The working pre-polish version is preserved at `/inbrnd/pre-polish/`, with a comparison at `/inbrnd/polish-comparison/`.

Phone typography uses responsive sizes through 600px: larger stage and curved ring labels, and an approximately 11–14% larger payoff. The teaching payoff reserves extra space at widths up to 360px. Wheel dimensions, colors, sequence, and reveal timing are unchanged. Version A retains the final sentence and hides explanatory copy.

Version A — Minimal: https://inbrnd.github.io/minimal/ (`content-mode="diagram"`). Version B — Educational: https://inbrnd.github.io/educational/ (`content-mode="teaching"`). Both share one component and scroll timeline, including the approved final sentence reveal.

Direct Server URL installs now default to Version A — Minimal when `content-mode` is omitted. Set `content-mode="teaching"` explicitly for Version B. Both retain the final sentence.
