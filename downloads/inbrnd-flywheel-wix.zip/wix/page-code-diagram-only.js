// Paste into the Wix page code after replacing the asset URL and header offset.
$w.onReady(() => {
  const wheel = $w('#inbrndFlywheel');
  wheel.setAttribute('asset-base', 'https://YOUR-ASSET-HOST/inbrnd/assets/');
  wheel.setAttribute('variant', 'wheel');
  wheel.setAttribute('emphasis', 'ring');
  wheel.setAttribute('content-mode', 'diagram');
  wheel.setAttribute('heading-level', '2');
  wheel.setAttribute('header-offset', '0');
});
